#ifndef CONO_H
#define CONO_H

#include "o3dr.h"

class Cono : public O3DR
{
public:
    Cono(int secciones,int angulo);
};

#endif // CONO_H
