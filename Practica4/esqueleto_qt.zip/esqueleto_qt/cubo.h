#ifndef CUBO_H
#define CUBO_H

#include "o3d.h"

class Cubo : public O3D{

public:
    Cubo();

};

#endif // CUBO_H
