#ifndef TETRAEDRO_H
#define TETRAEDRO_H

#include "o3d.h"

class Tetraedro : public O3D
{
public:
    Tetraedro();
};

#endif // TETRAEDRO_H
