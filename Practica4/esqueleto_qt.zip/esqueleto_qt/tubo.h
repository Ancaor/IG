#ifndef TUBO_H
#define TUBO_H

#include "o3dr.h"

class Tubo : public O3DR
{
public:
    Tubo(int secciones,int angulo);
};

#endif // TUBO_H
