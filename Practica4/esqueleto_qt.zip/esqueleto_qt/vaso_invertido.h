#ifndef VASO_INVERTIDO_H
#define VASO_INVERTIDO_H

#include "o3dr.h"

class Vaso_Invertido : public O3DR
{
public:
    Vaso_Invertido(int secciones,int angulo);
};

#endif // VASO_INVERTIDO_H
