#ifndef VASO_H
#define VASO_H

#include "o3dr.h"

class Vaso : public O3DR
{
public:
    Vaso(int secciones,int angulo);
};

#endif // VASO_H
