#ifndef ESFERA_H
#define ESFERA_H

#include "o3dr.h"

class Esfera : public O3DR
{
public:
    Esfera(int secciones,int angulo);
};

#endif // ESFERA_H
