#ifndef CILINDRO_H
#define CILINDRO_H

#include "o3dr.h"

class Cilindro : public O3DR
{
public:
    Cilindro(int secciones,int angulo);
};

#endif // CILINDRO_H
